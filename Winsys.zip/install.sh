#!/data/data/com.termux/files/usr/bin/bash

clear
echo "== Установка вашей графической ОС в Termux =="
echo

# Проверка: установлен ли unzip
command -v unzip >/dev/null 2>&1 || pkg install -y unzip

# Распаковка архива Winsys.zip
echo "[*] Распаковка системы..."
unzip -o Winsys.zip -d $HOME/

# Проверка и установка нужных пакетов
echo "[*] Установка зависимостей..."
pkg update -y && pkg install -y x11-repo
pkg install -y termux-x11 zenity mpv openbox feh xdotool firefox netsurf pcmanfm abiword gnumeric mtpaint leafpad galculator xterm htop

# Разрешения для скриптов
chmod +x $HOME/Winsys/*.sh
chmod +x $HOME/Winsys/desktop.sh

# Готово!
echo
echo "== Установка завершена =="
echo "Для запуска ОС напишите: bash ~/Winsys/desktop.sh"
