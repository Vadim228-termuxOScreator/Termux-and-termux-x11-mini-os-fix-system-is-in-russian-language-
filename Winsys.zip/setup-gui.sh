#!/data/data/com.termux/files/usr/bin/bash

zenity --info --text="Установка графической ОС\nНажмите OK для начала"

unzip -o Winsys.zip -d $HOME/ || zenity --error --text="Ошибка распаковки"

termux-setup-storage
pkg update -y
pkg install -y x11-repo zenity mpv openbox feh xdotool firefox netsurf pcmanfm abiword gnumeric mtpaint leafpad galculator xterm htop unzip

chmod +x $HOME/Winsys/*.sh
chmod +x $HOME/Winsys/desktop.sh

zenity --info --text="Установка завершена!\nДля запуска: bash ~/Winsys/desktop.sh"
