#!/data/data/com.termux/files/usr/bin/bash

zenity --list --title="Настройки ОС" --column="Опции" \
  "Изменить тему" \
  "Изменить шрифт" \
  "Изменить имя пользователя" \
  "Сбросить фон рабочего стола" \
  "Настроить автозапуск музыки" \
  "Назад" | while read SETTING; do
    case $SETTING in
      "Изменить тему")
        zenity --info --text="Темы пока не реализованы."
        ;;
      "Изменить шрифт")
        zenity --info --text="Шрифты в разработке."
        ;;
      "Изменить имя пользователя")
        NEW_NAME=$(zenity --entry --title="Новое имя" --text="Введите новое имя:")
        [ -n "$NEW_NAME" ] && mv "$HOME/Winsys/users/$CURRENT_USER" "$HOME/Winsys/users/$NEW_NAME"
        ;;
      "Сбросить фон рабочего стола")
        rm -f "$USER_DIR/wallpaper.png"
        zenity --info --text="Фон сброшен до стандартного."
        ;;
      "Настроить автозапуск музыки")
        zenity --info --text="Функция в разработке."
        ;;
    esac
done
