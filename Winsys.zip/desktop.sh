#!/data/data/com.termux/files/usr/bin/bash

# Проверка на вложенный запуск (эмулятор)
if [ "$DESKTOP_EMULATED" = "1" ]; then
    export DISPLAY=:0
    openbox &
    feh --bg-scale "$HOME/Winsys/wallpaper/win10.png" &
    exit 0
fi

# Watchdog
bash "$HOME/Winsys/watchdog.sh" &

# Запуск X11
termux-x11 :0 &
export DISPLAY=:0

# Пути
WALLPAPER_DEFAULT="$HOME/Winsys/wallpaper/win10.png"
BOOTSCREEN="$HOME/Winsys/wallpaper/win10boot.png"
SOUND="$HOME/Winsys/sounds/startup.mp3"
MUSIC_DIR="$HOME/Winsys/music"
USERS_DIR="$HOME/Winsys/users"

# Ждём подключения X-сервера
sleep 4
for i in {1..20}; do
    if xdpyinfo >/dev/null 2>&1; then break; fi
    echo "Ожидание X-сервера..."
    sleep 1
done

# Загрузочный экран
xsetroot -cursor_name none
feh --bg-scale "$BOOTSCREEN" &
sleep 4
pkill feh
xsetroot -cursor_name left_ptr

# Поддержка пользователей
mkdir -p "$USERS_DIR"
CURRENT_USER=$(zenity --entry --title="Выбор пользователя" --text="Введите имя пользователя:")
USER_DIR="$USERS_DIR/$CURRENT_USER"
mkdir -p "$USER_DIR"

# Обои пользователя
WALLPAPER="$WALLPAPER_DEFAULT"
[ -f "$USER_DIR/wallpaper.png" ] && WALLPAPER="$USER_DIR/wallpaper.png"

# Запуск openbox
openbox &
sleep 1

# Проверка пароля
PASSWORD=$(zenity --entry --title="Вход в систему" --text="Введите пароль:" --hide-text)
[ "$PASSWORD" != "148852" ] && zenity --error --text="Неверный пароль!" && exit

# Звук входа
mpv --no-video "$SOUND" &

# Установка обоев
feh --bg-scale "$WALLPAPER" &

### ИКОНКИ ###
ICON_FIREFOX="$HOME/Winsys/icons/firefox.png"
ICON_NET="$HOME/Winsys/icons/network.png"
ICON_MS="$HOME/Winsys/icons/microsoft.png"
feh --geometry 48x48+720+100 --no-fehbg "$ICON_MS" &
feh --geometry 64x64+20+20 --no-fehbg "$ICON_FIREFOX" &
feh --geometry 48x48+720+20 --no-fehbg "$ICON_NET" &

# Клик по иконке Firefox
(
while true; do
    eval "$(xdotool getmouselocation --shell)"
    if [ "$X" -ge 20 ] && [ "$X" -le 84 ] && [ "$Y" -ge 20 ] && [ "$Y" -le 84 ]; then
        firefox &
        sleep 1
    fi
    sleep 0.2
done
) &

# Клик по иконке Microsoft (Edge)
    if [ "$X" -ge 720 ] && [ "$X" -le 768 ] && [ "$Y" -ge 100 ] && [ "$Y" -le 148 ]; then
        bash $HOME/Winsys/winsore.sh
        sleep 1
    fi

# Проверка интернета каждые 10 секунд
(
while true; do
    if ping -c 1 8.8.8.8 >/dev/null 2>&1; then
        xmessage -geometry +720+80 -timeout 3 "Интернет подключён"
    else
        xmessage -geometry +720+80 -timeout 3 "Нет подключения"
    fi
    sleep 10
done
) &

### Меню Пуск ###
while true; do
CHOICE=$(zenity --list --title="Меню Пуск" --column="Приложения" \
"Файрфокс" "NetSurf" "Файлы" "Музыка" "Почта" "Пейнт" "Офис - Abiword" \
"Офис - Gnumeric" "WinStore" "Эмулятор DesktopSX" "QEMU: Запуск ISO" \
"Настройки ОС" "Панель управления" "Диспетчер задач" "Калькулятор (galculator)" \
"Блокнот" "Сон" "Обновить интерфейс" "Выход")

case $CHOICE in
"Файрфокс") firefox & ;;
"NetSurf") netsurf & ;;
"Файлы") pcmanfm & ;;
"Музыка")
    FILE=$(zenity --file-selection --title="Выберите аудиофайл" --filename="$MUSIC_DIR/")
    [ -n "$FILE" ] && mpv "$FILE" &
    ;;
"Почта") firefox "https://mail.google.com" & ;;
"Пейнт") mtpaint & ;;
"Офис - Abiword") abiword & ;;
"Офис - Gnumeric") gnumeric & ;;
"WinStore") bash "$HOME/Winsys/winstore.sh" & ;;
"Эмулятор DesktopSX")
    xterm -e "DESKTOP_EMULATED=1 bash $HOME/Winsys/desktop.sh; read -p 'Закрыть эмулятор...'"
    ;;
"QEMU: Запуск ISO")
    ISO=$(zenity --file-selection --title="Выберите ISO")
    VHD=$(zenity --file-selection --title="Выберите VHD")
    UEFI=$(zenity --file-selection --title="Выберите BIOS")
    RAM=$(zenity --entry --title="ОЗУ" --text="Сколько MB RAM?" --entry-text="2048")
    [ -n "$ISO" ] && [ -n "$VHD" ] && [ -n "$UEFI" ] && [ -n "$RAM" ] && \
    xterm -e "qemu-system-aarch64 -machine virt -cpu cortex-a72 -smp 4 -m $RAM -bios \"$UEFI\" -drive if=virtio,file=\"$VHD\",format=raw -cdrom \"$ISO\" -device virtio-gpu-pci -nographic; read"
    ;;
"Настройки ОС") bash "$HOME/Winsys/settings.sh" & ;;
"Панель управления")
    zenity --list --title="Панель управления" --column="Опции" \
    "Сменить пользователя" "Сменить обои" "Сменить курсор" "Сменить тему" \
    "Сменить пароль" "Назад" | while read OPTION; do
        case $OPTION in
            "Сменить пользователя") exec "$HOME/Winsys/desktop.sh" ;;
            "Сменить обои")
                NEW_BG=$(zenity --file-selection --title="Выберите обои")
                [ -f "$NEW_BG" ] && cp "$NEW_BG" "$USER_DIR/wallpaper.png"
                ;;
            "Сменить курсор") xsetroot -cursor_name question_arrow ;;
            "Сменить тему") zenity --info --text="Темы пока в разработке" ;;
            "Сменить пароль")
                NEWPASS=$(zenity --entry --title="Новый пароль" --hide-text)
                echo "$NEWPASS" > "$USER_DIR/pass.txt"
                ;;
        esac
    done
    ;;
"Диспетчер задач") xterm -e htop & ;;
"Калькулятор (galculator)") galculator & ;;
"Блокнот") leafpad & ;;
"Сон")
    xsetroot -solid black
    zenity --info --text="Пробуждение — касание экрана"
    ;;
"Обновить интерфейс")
    pkill openbox
    openbox &
    feh --bg-scale "$WALLPAPER" &
    ;;
"Выход")
    pkill openbox
    exit
    ;;
esac
done
